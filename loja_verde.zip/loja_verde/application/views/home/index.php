<?php
$base = __DIR__;
include $base .'\..\layout\menu.php'; 
//debug_print_backtrace();
 ?>
<html>
<head>

</head>
<body>
    <h1> Bem-Vindo </h1>
    <hr />
    <p> Minha Página </p>

    <!-- Formulário de pesquisa -->
<form action="/usuario/pesquisar" method="GET">
    <input type="text" name="pesquisa" placeholder="Digite o termo de pesquisa">
    <input type="submit" value="Pesquisar">
</form>

<!-- Exibir os resultados da pesquisa -->
<?php if (isset($data['resultados']) && !empty($data['resultados'])) { ?>
    <h2>Resultados da Pesquisa:</h2>
    <ul>
        <?php foreach ($data['resultados'] as $resultado) { ?>
            <li><?= $resultado->getNome() ?></li>
        <?php } ?>
    </ul>
<?php } else { ?>
    <p>Nenhum resultado encontrado.</p>
<?php } ?>
</body>
</html>