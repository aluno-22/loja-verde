<div class="container">
  <div class="row">
    <div class="col-12 text-center">
      <img src="assets/img/erro.png">
      <h1> Error 404 </h1>
    </div>
  </div>
</div>
